# Bottles Store

A simple HTML and CSS webpage showcasing different bottles for sale.

## How to Use
1. Open `index.html` in a browser.
2. See different bottle options and pricing.
3. Click 'Buy Now' to simulate purchasing.

## Files Included
- `index.html` - Main webpage.
- `README.md` - Documentation.

## Note
You need to add actual bottle images and update `bottle.png` accordingly.
